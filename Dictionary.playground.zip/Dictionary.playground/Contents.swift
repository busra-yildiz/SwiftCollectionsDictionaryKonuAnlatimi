import UIKit

var gidalarinReyonu = [Int:String]()

//Veri ekleme şekli
gidalarinReyonu[15] = "MEYVE"
gidalarinReyonu[3] = "MAKARNA"
print(gidalarinReyonu)


//veri okuma
print(gidalarinReyonu[15]!)

//veri güncelleme
gidalarinReyonu[15] = "MEYVE VE SEBZE"
print(gidalarinReyonu)


//döngülerle çalışma
for (anahtar, deger) in gidalarinReyonu {
    print("\(anahtar) -> \(deger)")
}


//silme işlemleri keye göre yapılır.
gidalarinReyonu.removeValue(forKey: 3)  //dictionary silme komutu .removeValue olarak geçer.
print(gidalarinReyonu)
